{-# LANGUAGE DataKinds #-}
{-# LANGUAGE TemplateHaskell #-}

module THFixtures where

import Proto.TH (loadProto)


$(loadProto "test-regression/proto/edition2023.proto")
$(loadProto "test-regression/proto/edition2024.proto")
$(loadProto "test-regression/proto/json_numbers.proto")


$(loadProto "test-regression/proto/integerMaps.proto")
