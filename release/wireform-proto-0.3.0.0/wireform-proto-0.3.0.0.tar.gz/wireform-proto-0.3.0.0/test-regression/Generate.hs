{-# LANGUAGE ImportQualifiedPost #-}
{-# LANGUAGE OverloadedStrings #-}

-- Run from wireform-proto: cabal exec -- runghc test-regression/Generate.hs
module Main where

import Data.Map.Strict qualified as Map
import Data.Text qualified as T
import Data.Text.IO qualified as TIO
import Proto.CodeGen
import Proto.IDL.Parser
import Proto.IDL.Parser.Resolver (ResolvedProto (..))
import System.Directory (createDirectoryIfMissing)
import System.FilePath (takeDirectory, (</>))


main :: IO ()
main = mapM_ generate ["edition2023", "edition2024", "integerMaps"]
  where
    generate name = do
      let file = name <> ".proto"
      source <- TIO.readFile ("test-regression/proto" </> file)
      pf <- either (fail . show) pure (parseProtoFile file source)
      let opts = defaultGenerateOpts {genModulePrefix = "Generated"}
          registry = buildTypeRegistry opts [(file, ResolvedProto pf file Map.empty)]
          output = "test-regression" </> T.unpack (T.replace "." "/" (moduleNameForProto opts file pf)) <> ".hs"
      createDirectoryIfMissing True (takeDirectory output)
      TIO.writeFile output (generateModuleText opts registry file pf)
